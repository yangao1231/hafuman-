#include<stdio.h>
#include<stdlib.h>
#include<iostream>
using namespace std;
typedef struct node
{
	char a;
	float chance;
	int lr;
	int flag;
	int parent;
}node,* linklist;
node v[100000];
void creat(int& m)
{
	
	cin>>m;
	for(int i=1;i<=m;i++)
	{
		v[i].flag=0;
		cin>>v[i].a;
	}
	for(int i=1;i<=m;i++)
	{
		cin>>v[i].chance;
	}/*��ʼ��*/
	float min,cmin;
	int vmin,vcmin;
	int mm=m;
	while(1)
	{
		min=2,cmin=2;
		for(int i=1;i<=mm;i++)
		{
			if(v[i].flag==0&&min>v[i].chance)
			{
				min=v[i].chance;
				vmin=i;
			}
		}
		v[vmin].flag=1;/*Ѱ����С��*/
		for(int i=1;i<=mm;i++)
		{
			if(v[i].flag==0&&cmin>v[i].chance)
			{
				cmin=v[i].chance;
				vcmin=i;
			}
		}
		v[vcmin].flag=1;/*Ѱ�Ҵ�С��*/
		v[++mm].chance=v[vmin].chance+v[vcmin].chance;
		v[mm].flag=0;
		v[vmin].parent=mm;
		v[vcmin].parent=mm;
		v[vmin].lr=0;
		v[vcmin].lr=1;
		if(v[mm].chance==1)
			break;
	}
}
void print(int m)
{
	int top=0;
	int stack[100];
	for(int i=1;i<=m;i++)
	{
		int y=i;
		while(v[y].chance!=1)
		{
			stack[++top]=v[y].lr;
			y=v[y].parent;
		}
		cout<<"The "<<v[i].a<<"'s Huffman code is:";
		while(top!=0)
		{
			cout<<stack[top--];
		}
		cout<<"\n";
	}
}
int main()
{
	int m;
	creat(m);
	print(m);
	return 0;
}